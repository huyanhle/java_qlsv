﻿namespace QuanLy
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabCtrl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnGiaHanHV = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.btnSearchHV = new System.Windows.Forms.Button();
            this.txtSearchHV = new System.Windows.Forms.TextBox();
            this.btnXoaHV = new System.Windows.Forms.Button();
            this.btnSuaHV = new System.Windows.Forms.Button();
            this.btnThemHV = new System.Windows.Forms.Button();
            this.dtgvHoiVien = new System.Windows.Forms.DataGridView();
            this.id_hv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hoten = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBoxHV = new System.Windows.Forms.GroupBox();
            this.btnLuuHV = new System.Windows.Forms.Button();
            this.cmbGioiTinh = new System.Windows.Forms.ComboBox();
            this.lblHetHan = new System.Windows.Forms.Label();
            this.picBoxHV = new System.Windows.Forms.PictureBox();
            this.lblNgayHetHan = new System.Windows.Forms.Label();
            this.cmbGoiTap = new System.Windows.Forms.ComboBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtMaHV = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLoaiSP = new System.Windows.Forms.TextBox();
            this.btnSearchSP = new System.Windows.Forms.Button();
            this.txtSearchSP = new System.Windows.Forms.TextBox();
            this.lblTinhTrangSP = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSuaSP = new System.Windows.Forms.Button();
            this.btnThemSP = new System.Windows.Forms.Button();
            this.btnXoaSP = new System.Windows.Forms.Button();
            this.dtgvSanPham = new System.Windows.Forms.DataGridView();
            this.id_sp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ten = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ngaynhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soluong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dongia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trongluong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hangsx = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tinhtrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtDonGiaSP = new System.Windows.Forms.TextBox();
            this.picBoxSP = new System.Windows.Forms.PictureBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.txtSoLuongSP = new System.Windows.Forms.TextBox();
            this.txtTenSP = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLoaiTB = new System.Windows.Forms.TextBox();
            this.txtSearchTB = new System.Windows.Forms.TextBox();
            this.lblTinhTrangTB = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnSuaTB = new System.Windows.Forms.Button();
            this.btnThemTB = new System.Windows.Forms.Button();
            this.btnXoaTB = new System.Windows.Forms.Button();
            this.dtgvThietBi = new System.Windows.Forms.DataGridView();
            this.id_tb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tentb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loaitb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soluongtb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hangsxtb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tinhtrangtb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soluonghu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ghichu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtHangSXTB = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtSoLuongTB = new System.Windows.Forms.TextBox();
            this.txtTenTB = new System.Windows.Forms.TextBox();
            this.btnSearchTB = new System.Windows.Forms.Button();
            this.picBoxTB = new System.Windows.Forms.PictureBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.imgList = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label33 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tabCtrl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvHoiVien)).BeginInit();
            this.groupBoxHV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxHV)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvSanPham)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSP)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvThietBi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTB)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // tabCtrl
            // 
            this.tabCtrl.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabCtrl.Controls.Add(this.tabPage1);
            this.tabCtrl.Controls.Add(this.tabPage2);
            this.tabCtrl.Controls.Add(this.tabPage3);
            this.tabCtrl.Controls.Add(this.tabPage4);
            this.tabCtrl.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabCtrl.ImageList = this.imgList;
            this.tabCtrl.ItemSize = new System.Drawing.Size(50, 120);
            this.tabCtrl.Location = new System.Drawing.Point(-3, 95);
            this.tabCtrl.Margin = new System.Windows.Forms.Padding(4);
            this.tabCtrl.Multiline = true;
            this.tabCtrl.Name = "tabCtrl";
            this.tabCtrl.SelectedIndex = 0;
            this.tabCtrl.Size = new System.Drawing.Size(1084, 553);
            this.tabCtrl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabCtrl.TabIndex = 0;
            this.tabCtrl.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabCtrl_DrawItem);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.btnGiaHanHV);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.btnSearchHV);
            this.tabPage1.Controls.Add(this.txtSearchHV);
            this.tabPage1.Controls.Add(this.btnXoaHV);
            this.tabPage1.Controls.Add(this.btnSuaHV);
            this.tabPage1.Controls.Add(this.btnThemHV);
            this.tabPage1.Controls.Add(this.dtgvHoiVien);
            this.tabPage1.Controls.Add(this.groupBoxHV);
            this.tabPage1.ImageIndex = 0;
            this.tabPage1.Location = new System.Drawing.Point(124, 4);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(956, 545);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Hội viên";
            // 
            // btnGiaHanHV
            // 
            this.btnGiaHanHV.Enabled = false;
            this.btnGiaHanHV.Location = new System.Drawing.Point(367, 241);
            this.btnGiaHanHV.Margin = new System.Windows.Forms.Padding(4);
            this.btnGiaHanHV.Name = "btnGiaHanHV";
            this.btnGiaHanHV.Size = new System.Drawing.Size(100, 28);
            this.btnGiaHanHV.TabIndex = 27;
            this.btnGiaHanHV.Text = "Gia hạn";
            this.btnGiaHanHV.UseVisualStyleBackColor = true;
            this.btnGiaHanHV.Click += new System.EventHandler(this.btn_giahanhv_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(51, 10);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(235, 35);
            this.label31.TabIndex = 25;
            this.label31.Text = "Danh sách hội viên";
            // 
            // btnSearchHV
            // 
            this.btnSearchHV.BackColor = System.Drawing.Color.Transparent;
            this.btnSearchHV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchHV.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSearchHV.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchHV.Image")));
            this.btnSearchHV.Location = new System.Drawing.Point(312, 53);
            this.btnSearchHV.Margin = new System.Windows.Forms.Padding(4);
            this.btnSearchHV.Name = "btnSearchHV";
            this.btnSearchHV.Size = new System.Drawing.Size(40, 37);
            this.btnSearchHV.TabIndex = 6;
            this.btnSearchHV.UseVisualStyleBackColor = false;
            this.btnSearchHV.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearchHV
            // 
            this.txtSearchHV.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtSearchHV.Location = new System.Drawing.Point(107, 60);
            this.txtSearchHV.Margin = new System.Windows.Forms.Padding(4);
            this.txtSearchHV.Name = "txtSearchHV";
            this.txtSearchHV.Size = new System.Drawing.Size(201, 22);
            this.txtSearchHV.TabIndex = 5;
            this.txtSearchHV.Text = "Search...";
            this.txtSearchHV.Enter += new System.EventHandler(this.HoiVienSearch_Enter);
            this.txtSearchHV.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            this.txtSearchHV.Leave += new System.EventHandler(this.HoiVienSearch_Leave);
            // 
            // btnXoaHV
            // 
            this.btnXoaHV.Location = new System.Drawing.Point(367, 150);
            this.btnXoaHV.Margin = new System.Windows.Forms.Padding(4);
            this.btnXoaHV.Name = "btnXoaHV";
            this.btnXoaHV.Size = new System.Drawing.Size(100, 28);
            this.btnXoaHV.TabIndex = 4;
            this.btnXoaHV.Text = "Xóa";
            this.btnXoaHV.UseVisualStyleBackColor = true;
            this.btnXoaHV.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnSuaHV
            // 
            this.btnSuaHV.Location = new System.Drawing.Point(367, 196);
            this.btnSuaHV.Margin = new System.Windows.Forms.Padding(4);
            this.btnSuaHV.Name = "btnSuaHV";
            this.btnSuaHV.Size = new System.Drawing.Size(100, 28);
            this.btnSuaHV.TabIndex = 3;
            this.btnSuaHV.Text = "Sửa";
            this.btnSuaHV.UseVisualStyleBackColor = true;
            this.btnSuaHV.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnThemHV
            // 
            this.btnThemHV.Location = new System.Drawing.Point(367, 105);
            this.btnThemHV.Margin = new System.Windows.Forms.Padding(4);
            this.btnThemHV.Name = "btnThemHV";
            this.btnThemHV.Size = new System.Drawing.Size(100, 28);
            this.btnThemHV.TabIndex = 2;
            this.btnThemHV.Text = "Thêm";
            this.btnThemHV.UseVisualStyleBackColor = true;
            this.btnThemHV.Click += new System.EventHandler(this.btn_themhv_Click);
            // 
            // dtgvHoiVien
            // 
            this.dtgvHoiVien.AllowUserToAddRows = false;
            this.dtgvHoiVien.AllowUserToDeleteRows = false;
            this.dtgvHoiVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvHoiVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id_hv,
            this.hoten});
            this.dtgvHoiVien.Location = new System.Drawing.Point(7, 102);
            this.dtgvHoiVien.Margin = new System.Windows.Forms.Padding(4);
            this.dtgvHoiVien.Name = "dtgvHoiVien";
            this.dtgvHoiVien.ReadOnly = true;
            this.dtgvHoiVien.RowHeadersWidth = 51;
            this.dtgvHoiVien.Size = new System.Drawing.Size(343, 434);
            this.dtgvHoiVien.TabIndex = 0;
            this.dtgvHoiVien.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvHoiVien_CellEnter);
            // 
            // id_hv
            // 
            this.id_hv.DataPropertyName = "id_hv";
            this.id_hv.HeaderText = "Mã hội viên";
            this.id_hv.MinimumWidth = 6;
            this.id_hv.Name = "id_hv";
            this.id_hv.ReadOnly = true;
            this.id_hv.Width = 90;
            // 
            // hoten
            // 
            this.hoten.DataPropertyName = "hoten";
            this.hoten.HeaderText = "Họ tên";
            this.hoten.MinimumWidth = 6;
            this.hoten.Name = "hoten";
            this.hoten.ReadOnly = true;
            this.hoten.Width = 125;
            // 
            // groupBoxHV
            // 
            this.groupBoxHV.Controls.Add(this.btnLuuHV);
            this.groupBoxHV.Controls.Add(this.cmbGioiTinh);
            this.groupBoxHV.Controls.Add(this.lblHetHan);
            this.groupBoxHV.Controls.Add(this.picBoxHV);
            this.groupBoxHV.Controls.Add(this.lblNgayHetHan);
            this.groupBoxHV.Controls.Add(this.cmbGoiTap);
            this.groupBoxHV.Controls.Add(this.txtSDT);
            this.groupBoxHV.Controls.Add(this.txtHoTen);
            this.groupBoxHV.Controls.Add(this.label28);
            this.groupBoxHV.Controls.Add(this.txtMaHV);
            this.groupBoxHV.Controls.Add(this.label27);
            this.groupBoxHV.Controls.Add(this.label25);
            this.groupBoxHV.Controls.Add(this.label24);
            this.groupBoxHV.Controls.Add(this.label26);
            this.groupBoxHV.Controls.Add(this.label23);
            this.groupBoxHV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxHV.Location = new System.Drawing.Point(485, 5);
            this.groupBoxHV.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxHV.Name = "groupBoxHV";
            this.groupBoxHV.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxHV.Size = new System.Drawing.Size(425, 530);
            this.groupBoxHV.TabIndex = 26;
            this.groupBoxHV.TabStop = false;
            this.groupBoxHV.Text = "Thông tin hội viên";
            // 
            // btnLuuHV
            // 
            this.btnLuuHV.Enabled = false;
            this.btnLuuHV.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuHV.Location = new System.Drawing.Point(276, 487);
            this.btnLuuHV.Margin = new System.Windows.Forms.Padding(4);
            this.btnLuuHV.Name = "btnLuuHV";
            this.btnLuuHV.Size = new System.Drawing.Size(79, 28);
            this.btnLuuHV.TabIndex = 28;
            this.btnLuuHV.Text = "Lưu";
            this.btnLuuHV.UseVisualStyleBackColor = true;
            this.btnLuuHV.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // cmbGioiTinh
            // 
            this.cmbGioiTinh.Enabled = false;
            this.cmbGioiTinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGioiTinh.FormattingEnabled = true;
            this.cmbGioiTinh.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.cmbGioiTinh.Location = new System.Drawing.Point(160, 326);
            this.cmbGioiTinh.Margin = new System.Windows.Forms.Padding(4);
            this.cmbGioiTinh.Name = "cmbGioiTinh";
            this.cmbGioiTinh.Size = new System.Drawing.Size(193, 25);
            this.cmbGioiTinh.TabIndex = 26;
            // 
            // lblHetHan
            // 
            this.lblHetHan.AutoSize = true;
            this.lblHetHan.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblHetHan.Location = new System.Drawing.Point(155, 447);
            this.lblHetHan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHetHan.Name = "lblHetHan";
            this.lblHetHan.Size = new System.Drawing.Size(54, 25);
            this.lblHetHan.TabIndex = 25;
            this.lblHetHan.Text = "date";
            // 
            // picBoxHV
            // 
            this.picBoxHV.Location = new System.Drawing.Point(67, 34);
            this.picBoxHV.Margin = new System.Windows.Forms.Padding(4);
            this.picBoxHV.Name = "picBoxHV";
            this.picBoxHV.Size = new System.Drawing.Size(301, 183);
            this.picBoxHV.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxHV.TabIndex = 24;
            this.picBoxHV.TabStop = false;
            this.picBoxHV.DoubleClick += new System.EventHandler(this.picBoxHV_DoubleClick);
            // 
            // lblNgayHetHan
            // 
            this.lblNgayHetHan.AutoSize = true;
            this.lblNgayHetHan.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNgayHetHan.Location = new System.Drawing.Point(155, 481);
            this.lblNgayHetHan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNgayHetHan.Name = "lblNgayHetHan";
            this.lblNgayHetHan.Size = new System.Drawing.Size(0, 25);
            this.lblNgayHetHan.TabIndex = 23;
            // 
            // cmbGoiTap
            // 
            this.cmbGoiTap.Enabled = false;
            this.cmbGoiTap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGoiTap.FormattingEnabled = true;
            this.cmbGoiTap.Items.AddRange(new object[] {
            "1 tháng",
            "3 tháng",
            "VIP",
            "Thường"});
            this.cmbGoiTap.Location = new System.Drawing.Point(160, 367);
            this.cmbGoiTap.Margin = new System.Windows.Forms.Padding(4);
            this.cmbGoiTap.Name = "cmbGoiTap";
            this.cmbGoiTap.Size = new System.Drawing.Size(193, 25);
            this.cmbGoiTap.TabIndex = 22;
            this.cmbGoiTap.TextChanged += new System.EventHandler(this.cmbGoiTap_TextChanged);
            // 
            // txtSDT
            // 
            this.txtSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT.Location = new System.Drawing.Point(160, 407);
            this.txtSDT.Margin = new System.Windows.Forms.Padding(4);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.ReadOnly = true;
            this.txtSDT.Size = new System.Drawing.Size(193, 23);
            this.txtSDT.TabIndex = 18;
            this.txtSDT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSDT_KeyPress);
            // 
            // txtHoTen
            // 
            this.txtHoTen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHoTen.Location = new System.Drawing.Point(160, 286);
            this.txtHoTen.Margin = new System.Windows.Forms.Padding(4);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.ReadOnly = true;
            this.txtHoTen.Size = new System.Drawing.Size(193, 23);
            this.txtHoTen.TabIndex = 15;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(48, 452);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(97, 17);
            this.label28.TabIndex = 13;
            this.label28.Text = "Ngày hết hạn:";
            // 
            // txtMaHV
            // 
            this.txtMaHV.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaHV.Location = new System.Drawing.Point(160, 245);
            this.txtMaHV.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaHV.Name = "txtMaHV";
            this.txtMaHV.ReadOnly = true;
            this.txtMaHV.Size = new System.Drawing.Size(193, 23);
            this.txtMaHV.TabIndex = 14;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(48, 411);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(95, 17);
            this.label27.TabIndex = 12;
            this.label27.Text = "Số điện thoại:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(48, 330);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(64, 17);
            this.label25.TabIndex = 10;
            this.label25.Text = "Giới tính:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(48, 289);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(54, 17);
            this.label24.TabIndex = 9;
            this.label24.Text = "Họ tên:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(48, 370);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(58, 17);
            this.label26.TabIndex = 11;
            this.label26.Text = "Gói tập:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(48, 249);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(84, 17);
            this.label23.TabIndex = 8;
            this.label23.Text = "Mã hội viên:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.txtLoaiSP);
            this.tabPage2.Controls.Add(this.btnSearchSP);
            this.tabPage2.Controls.Add(this.txtSearchSP);
            this.tabPage2.Controls.Add(this.lblTinhTrangSP);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.dtgvSanPham);
            this.tabPage2.Controls.Add(this.txtDonGiaSP);
            this.tabPage2.Controls.Add(this.picBoxSP);
            this.tabPage2.Controls.Add(this.label38);
            this.tabPage2.Controls.Add(this.label37);
            this.tabPage2.Controls.Add(this.label36);
            this.tabPage2.Controls.Add(this.label35);
            this.tabPage2.Controls.Add(this.txtSoLuongSP);
            this.tabPage2.Controls.Add(this.txtTenSP);
            this.tabPage2.ImageIndex = 1;
            this.tabPage2.Location = new System.Drawing.Point(124, 4);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(956, 545);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Sản phẩm";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(352, 66);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 17);
            this.label2.TabIndex = 39;
            this.label2.Text = "Loại:";
            // 
            // txtLoaiSP
            // 
            this.txtLoaiSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoaiSP.Location = new System.Drawing.Point(464, 63);
            this.txtLoaiSP.Margin = new System.Windows.Forms.Padding(4);
            this.txtLoaiSP.Name = "txtLoaiSP";
            this.txtLoaiSP.ReadOnly = true;
            this.txtLoaiSP.Size = new System.Drawing.Size(193, 23);
            this.txtLoaiSP.TabIndex = 7;
            // 
            // btnSearchSP
            // 
            this.btnSearchSP.BackColor = System.Drawing.Color.Transparent;
            this.btnSearchSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchSP.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSearchSP.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchSP.Image")));
            this.btnSearchSP.Location = new System.Drawing.Point(859, 6);
            this.btnSearchSP.Margin = new System.Windows.Forms.Padding(4);
            this.btnSearchSP.Name = "btnSearchSP";
            this.btnSearchSP.Size = new System.Drawing.Size(40, 37);
            this.btnSearchSP.TabIndex = 2;
            this.btnSearchSP.UseVisualStyleBackColor = false;
            this.btnSearchSP.Click += new System.EventHandler(this.btnSearchSP_Click);
            // 
            // txtSearchSP
            // 
            this.txtSearchSP.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtSearchSP.Location = new System.Drawing.Point(695, 14);
            this.txtSearchSP.Margin = new System.Windows.Forms.Padding(4);
            this.txtSearchSP.Name = "txtSearchSP";
            this.txtSearchSP.Size = new System.Drawing.Size(161, 22);
            this.txtSearchSP.TabIndex = 1;
            this.txtSearchSP.Text = "Search...";
            this.txtSearchSP.Enter += new System.EventHandler(this.txtSearchSP_Enter);
            this.txtSearchSP.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearchSP_KeyDown);
            this.txtSearchSP.Leave += new System.EventHandler(this.txtSearchSP_Leave);
            // 
            // lblTinhTrangSP
            // 
            this.lblTinhTrangSP.AutoSize = true;
            this.lblTinhTrangSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTinhTrangSP.Location = new System.Drawing.Point(459, 170);
            this.lblTinhTrangSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTinhTrangSP.Name = "lblTinhTrangSP";
            this.lblTinhTrangSP.Size = new System.Drawing.Size(24, 25);
            this.lblTinhTrangSP.TabIndex = 36;
            this.lblTinhTrangSP.Text = "tt";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSuaSP);
            this.groupBox2.Controls.Add(this.btnThemSP);
            this.groupBox2.Controls.Add(this.btnXoaSP);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(695, 50);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(177, 156);
            this.groupBox2.TabIndex = 35;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chức năng";
            // 
            // btnSuaSP
            // 
            this.btnSuaSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaSP.Location = new System.Drawing.Point(40, 110);
            this.btnSuaSP.Margin = new System.Windows.Forms.Padding(4);
            this.btnSuaSP.Name = "btnSuaSP";
            this.btnSuaSP.Size = new System.Drawing.Size(100, 28);
            this.btnSuaSP.TabIndex = 5;
            this.btnSuaSP.Text = "Sửa";
            this.btnSuaSP.UseVisualStyleBackColor = true;
            this.btnSuaSP.Click += new System.EventHandler(this.btnSuaSP_Click);
            // 
            // btnThemSP
            // 
            this.btnThemSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemSP.Location = new System.Drawing.Point(40, 38);
            this.btnThemSP.Margin = new System.Windows.Forms.Padding(4);
            this.btnThemSP.Name = "btnThemSP";
            this.btnThemSP.Size = new System.Drawing.Size(100, 28);
            this.btnThemSP.TabIndex = 3;
            this.btnThemSP.Text = "Thêm";
            this.btnThemSP.UseVisualStyleBackColor = true;
            this.btnThemSP.Click += new System.EventHandler(this.btnThemSP_Click);
            // 
            // btnXoaSP
            // 
            this.btnXoaSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaSP.Location = new System.Drawing.Point(40, 74);
            this.btnXoaSP.Margin = new System.Windows.Forms.Padding(4);
            this.btnXoaSP.Name = "btnXoaSP";
            this.btnXoaSP.Size = new System.Drawing.Size(100, 28);
            this.btnXoaSP.TabIndex = 4;
            this.btnXoaSP.Text = "Xóa";
            this.btnXoaSP.UseVisualStyleBackColor = true;
            this.btnXoaSP.Click += new System.EventHandler(this.btnXoaSP_Click);
            // 
            // dtgvSanPham
            // 
            this.dtgvSanPham.AllowUserToAddRows = false;
            this.dtgvSanPham.AllowUserToDeleteRows = false;
            this.dtgvSanPham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvSanPham.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id_sp,
            this.ten,
            this.loai,
            this.ngaynhap,
            this.soluong,
            this.dongia,
            this.trongluong,
            this.hangsx,
            this.tinhtrang});
            this.dtgvSanPham.Location = new System.Drawing.Point(3, 224);
            this.dtgvSanPham.Margin = new System.Windows.Forms.Padding(4);
            this.dtgvSanPham.Name = "dtgvSanPham";
            this.dtgvSanPham.RowHeadersWidth = 51;
            this.dtgvSanPham.Size = new System.Drawing.Size(904, 313);
            this.dtgvSanPham.TabIndex = 10;
            this.dtgvSanPham.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvSanPham_CellEnter);
            // 
            // id_sp
            // 
            this.id_sp.DataPropertyName = "id_sp";
            this.id_sp.HeaderText = "Mã sản phẩm";
            this.id_sp.MinimumWidth = 6;
            this.id_sp.Name = "id_sp";
            this.id_sp.Width = 125;
            // 
            // ten
            // 
            this.ten.DataPropertyName = "ten";
            this.ten.HeaderText = "Tên";
            this.ten.MinimumWidth = 6;
            this.ten.Name = "ten";
            this.ten.Width = 51;
            // 
            // loai
            // 
            this.loai.DataPropertyName = "loai";
            this.loai.HeaderText = "Loại";
            this.loai.MinimumWidth = 6;
            this.loai.Name = "loai";
            this.loai.Width = 125;
            // 
            // ngaynhap
            // 
            this.ngaynhap.DataPropertyName = "ngaynhap";
            this.ngaynhap.HeaderText = "Ngày nhập";
            this.ngaynhap.MinimumWidth = 6;
            this.ngaynhap.Name = "ngaynhap";
            this.ngaynhap.Width = 125;
            // 
            // soluong
            // 
            this.soluong.DataPropertyName = "soluong";
            this.soluong.HeaderText = "Số lượng";
            this.soluong.MinimumWidth = 6;
            this.soluong.Name = "soluong";
            this.soluong.Width = 125;
            // 
            // dongia
            // 
            this.dongia.DataPropertyName = "dongia";
            this.dongia.HeaderText = "Đơn giá";
            this.dongia.MinimumWidth = 6;
            this.dongia.Name = "dongia";
            this.dongia.Width = 125;
            // 
            // trongluong
            // 
            this.trongluong.DataPropertyName = "trongluong";
            this.trongluong.HeaderText = "Trọng lượng";
            this.trongluong.MinimumWidth = 6;
            this.trongluong.Name = "trongluong";
            this.trongluong.Width = 125;
            // 
            // hangsx
            // 
            this.hangsx.DataPropertyName = "hangsx";
            this.hangsx.HeaderText = "Hãng sản xuất";
            this.hangsx.MinimumWidth = 6;
            this.hangsx.Name = "hangsx";
            this.hangsx.Width = 125;
            // 
            // tinhtrang
            // 
            this.tinhtrang.DataPropertyName = "tinhtrang";
            this.tinhtrang.HeaderText = "Tình trạng";
            this.tinhtrang.MinimumWidth = 6;
            this.tinhtrang.Name = "tinhtrang";
            this.tinhtrang.Width = 125;
            // 
            // txtDonGiaSP
            // 
            this.txtDonGiaSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDonGiaSP.Location = new System.Drawing.Point(464, 132);
            this.txtDonGiaSP.Margin = new System.Windows.Forms.Padding(4);
            this.txtDonGiaSP.Name = "txtDonGiaSP";
            this.txtDonGiaSP.ReadOnly = true;
            this.txtDonGiaSP.Size = new System.Drawing.Size(193, 23);
            this.txtDonGiaSP.TabIndex = 9;
            // 
            // picBoxSP
            // 
            this.picBoxSP.Location = new System.Drawing.Point(21, 18);
            this.picBoxSP.Margin = new System.Windows.Forms.Padding(4);
            this.picBoxSP.Name = "picBoxSP";
            this.picBoxSP.Size = new System.Drawing.Size(301, 183);
            this.picBoxSP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxSP.TabIndex = 24;
            this.picBoxSP.TabStop = false;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(352, 135);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(61, 17);
            this.label38.TabIndex = 29;
            this.label38.Text = "Đơn giá:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(352, 101);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(68, 17);
            this.label37.TabIndex = 8;
            this.label37.Text = "Số lượng:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label36.Location = new System.Drawing.Point(352, 174);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(77, 17);
            this.label36.TabIndex = 11;
            this.label36.Text = "Tình trạng:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(352, 32);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(37, 17);
            this.label35.TabIndex = 9;
            this.label35.Text = "Tên:";
            // 
            // txtSoLuongSP
            // 
            this.txtSoLuongSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoLuongSP.Location = new System.Drawing.Point(464, 97);
            this.txtSoLuongSP.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoLuongSP.Name = "txtSoLuongSP";
            this.txtSoLuongSP.ReadOnly = true;
            this.txtSoLuongSP.Size = new System.Drawing.Size(193, 23);
            this.txtSoLuongSP.TabIndex = 8;
            // 
            // txtTenSP
            // 
            this.txtTenSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenSP.Location = new System.Drawing.Point(464, 28);
            this.txtTenSP.Margin = new System.Windows.Forms.Padding(4);
            this.txtTenSP.Name = "txtTenSP";
            this.txtTenSP.ReadOnly = true;
            this.txtTenSP.Size = new System.Drawing.Size(193, 23);
            this.txtTenSP.TabIndex = 6;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.txtLoaiTB);
            this.tabPage3.Controls.Add(this.txtSearchTB);
            this.tabPage3.Controls.Add(this.lblTinhTrangTB);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.dtgvThietBi);
            this.tabPage3.Controls.Add(this.txtHangSXTB);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.txtSoLuongTB);
            this.tabPage3.Controls.Add(this.txtTenTB);
            this.tabPage3.Controls.Add(this.btnSearchTB);
            this.tabPage3.Controls.Add(this.picBoxTB);
            this.tabPage3.ImageIndex = 2;
            this.tabPage3.Location = new System.Drawing.Point(124, 4);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(956, 545);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Thiết bị";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(353, 66);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 17);
            this.label3.TabIndex = 54;
            this.label3.Text = "Loại:";
            // 
            // txtLoaiTB
            // 
            this.txtLoaiTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoaiTB.Location = new System.Drawing.Point(465, 63);
            this.txtLoaiTB.Margin = new System.Windows.Forms.Padding(4);
            this.txtLoaiTB.Name = "txtLoaiTB";
            this.txtLoaiTB.ReadOnly = true;
            this.txtLoaiTB.Size = new System.Drawing.Size(193, 23);
            this.txtLoaiTB.TabIndex = 43;
            // 
            // txtSearchTB
            // 
            this.txtSearchTB.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtSearchTB.Location = new System.Drawing.Point(696, 14);
            this.txtSearchTB.Margin = new System.Windows.Forms.Padding(4);
            this.txtSearchTB.Name = "txtSearchTB";
            this.txtSearchTB.Size = new System.Drawing.Size(161, 22);
            this.txtSearchTB.TabIndex = 40;
            this.txtSearchTB.Text = "Search...";
            this.txtSearchTB.Enter += new System.EventHandler(this.txtSearchTB_Enter);
            this.txtSearchTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearchTB_KeyDown);
            this.txtSearchTB.Leave += new System.EventHandler(this.txtSearchTB_Leave);
            // 
            // lblTinhTrangTB
            // 
            this.lblTinhTrangTB.AutoSize = true;
            this.lblTinhTrangTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTinhTrangTB.Location = new System.Drawing.Point(460, 170);
            this.lblTinhTrangTB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTinhTrangTB.Name = "lblTinhTrangTB";
            this.lblTinhTrangTB.Size = new System.Drawing.Size(24, 25);
            this.lblTinhTrangTB.TabIndex = 53;
            this.lblTinhTrangTB.Text = "tt";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnSuaTB);
            this.groupBox3.Controls.Add(this.btnThemTB);
            this.groupBox3.Controls.Add(this.btnXoaTB);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(696, 50);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(177, 156);
            this.groupBox3.TabIndex = 52;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Chức năng";
            // 
            // btnSuaTB
            // 
            this.btnSuaTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaTB.Location = new System.Drawing.Point(40, 110);
            this.btnSuaTB.Margin = new System.Windows.Forms.Padding(4);
            this.btnSuaTB.Name = "btnSuaTB";
            this.btnSuaTB.Size = new System.Drawing.Size(100, 28);
            this.btnSuaTB.TabIndex = 5;
            this.btnSuaTB.Text = "Sửa";
            this.btnSuaTB.UseVisualStyleBackColor = true;
            this.btnSuaTB.Click += new System.EventHandler(this.btnSuaTB_Click);
            // 
            // btnThemTB
            // 
            this.btnThemTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemTB.Location = new System.Drawing.Point(40, 38);
            this.btnThemTB.Margin = new System.Windows.Forms.Padding(4);
            this.btnThemTB.Name = "btnThemTB";
            this.btnThemTB.Size = new System.Drawing.Size(100, 28);
            this.btnThemTB.TabIndex = 3;
            this.btnThemTB.Text = "Thêm";
            this.btnThemTB.UseVisualStyleBackColor = true;
            this.btnThemTB.Click += new System.EventHandler(this.btnThemTB_Click);
            // 
            // btnXoaTB
            // 
            this.btnXoaTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaTB.Location = new System.Drawing.Point(40, 74);
            this.btnXoaTB.Margin = new System.Windows.Forms.Padding(4);
            this.btnXoaTB.Name = "btnXoaTB";
            this.btnXoaTB.Size = new System.Drawing.Size(100, 28);
            this.btnXoaTB.TabIndex = 4;
            this.btnXoaTB.Text = "Xóa";
            this.btnXoaTB.UseVisualStyleBackColor = true;
            this.btnXoaTB.Click += new System.EventHandler(this.btnXoaTB_Click);
            // 
            // dtgvThietBi
            // 
            this.dtgvThietBi.AllowUserToAddRows = false;
            this.dtgvThietBi.AllowUserToDeleteRows = false;
            this.dtgvThietBi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvThietBi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id_tb,
            this.tentb,
            this.loaitb,
            this.soluongtb,
            this.hangsxtb,
            this.tinhtrangtb,
            this.soluonghu,
            this.ghichu});
            this.dtgvThietBi.Location = new System.Drawing.Point(4, 224);
            this.dtgvThietBi.Margin = new System.Windows.Forms.Padding(4);
            this.dtgvThietBi.Name = "dtgvThietBi";
            this.dtgvThietBi.RowHeadersWidth = 51;
            this.dtgvThietBi.Size = new System.Drawing.Size(904, 313);
            this.dtgvThietBi.TabIndex = 48;
            this.dtgvThietBi.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvThietBi_CellEnter);
            // 
            // id_tb
            // 
            this.id_tb.DataPropertyName = "id_tb";
            this.id_tb.HeaderText = "Mã thiết bị";
            this.id_tb.MinimumWidth = 6;
            this.id_tb.Name = "id_tb";
            this.id_tb.Width = 125;
            // 
            // tentb
            // 
            this.tentb.DataPropertyName = "ten";
            this.tentb.HeaderText = "Tên";
            this.tentb.MinimumWidth = 6;
            this.tentb.Name = "tentb";
            this.tentb.Width = 51;
            // 
            // loaitb
            // 
            this.loaitb.DataPropertyName = "loai";
            this.loaitb.HeaderText = "Loại";
            this.loaitb.MinimumWidth = 6;
            this.loaitb.Name = "loaitb";
            this.loaitb.Width = 125;
            // 
            // soluongtb
            // 
            this.soluongtb.DataPropertyName = "soluong";
            this.soluongtb.HeaderText = "Số lượng";
            this.soluongtb.MinimumWidth = 6;
            this.soluongtb.Name = "soluongtb";
            this.soluongtb.Width = 125;
            // 
            // hangsxtb
            // 
            this.hangsxtb.DataPropertyName = "hangsx";
            this.hangsxtb.HeaderText = "Hãng sản xuất";
            this.hangsxtb.MinimumWidth = 6;
            this.hangsxtb.Name = "hangsxtb";
            this.hangsxtb.Width = 125;
            // 
            // tinhtrangtb
            // 
            this.tinhtrangtb.DataPropertyName = "tinhtrang";
            this.tinhtrangtb.HeaderText = "Tình trạng";
            this.tinhtrangtb.MinimumWidth = 6;
            this.tinhtrangtb.Name = "tinhtrangtb";
            this.tinhtrangtb.Width = 125;
            // 
            // soluonghu
            // 
            this.soluonghu.DataPropertyName = "soluonghu";
            this.soluonghu.HeaderText = "Số lượng hư";
            this.soluonghu.MinimumWidth = 6;
            this.soluonghu.Name = "soluonghu";
            this.soluonghu.Width = 125;
            // 
            // ghichu
            // 
            this.ghichu.DataPropertyName = "ghichu";
            this.ghichu.HeaderText = "Ghi chú";
            this.ghichu.MinimumWidth = 6;
            this.ghichu.Name = "ghichu";
            this.ghichu.Width = 125;
            // 
            // txtHangSXTB
            // 
            this.txtHangSXTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHangSXTB.Location = new System.Drawing.Point(465, 132);
            this.txtHangSXTB.Margin = new System.Windows.Forms.Padding(4);
            this.txtHangSXTB.Name = "txtHangSXTB";
            this.txtHangSXTB.ReadOnly = true;
            this.txtHangSXTB.Size = new System.Drawing.Size(193, 23);
            this.txtHangSXTB.TabIndex = 46;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(353, 135);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 17);
            this.label12.TabIndex = 51;
            this.label12.Text = "Hãng sản xuất:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(353, 101);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 17);
            this.label13.TabIndex = 44;
            this.label13.Text = "Số lượng:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label14.Location = new System.Drawing.Point(353, 174);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 17);
            this.label14.TabIndex = 49;
            this.label14.Text = "Tình trạng:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(353, 32);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 17);
            this.label15.TabIndex = 47;
            this.label15.Text = "Tên:";
            // 
            // txtSoLuongTB
            // 
            this.txtSoLuongTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoLuongTB.Location = new System.Drawing.Point(465, 97);
            this.txtSoLuongTB.Margin = new System.Windows.Forms.Padding(4);
            this.txtSoLuongTB.Name = "txtSoLuongTB";
            this.txtSoLuongTB.ReadOnly = true;
            this.txtSoLuongTB.Size = new System.Drawing.Size(193, 23);
            this.txtSoLuongTB.TabIndex = 45;
            // 
            // txtTenTB
            // 
            this.txtTenTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenTB.Location = new System.Drawing.Point(465, 28);
            this.txtTenTB.Margin = new System.Windows.Forms.Padding(4);
            this.txtTenTB.Name = "txtTenTB";
            this.txtTenTB.ReadOnly = true;
            this.txtTenTB.Size = new System.Drawing.Size(193, 23);
            this.txtTenTB.TabIndex = 42;
            // 
            // btnSearchTB
            // 
            this.btnSearchTB.BackColor = System.Drawing.Color.Transparent;
            this.btnSearchTB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchTB.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSearchTB.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchTB.Image")));
            this.btnSearchTB.Location = new System.Drawing.Point(860, 6);
            this.btnSearchTB.Margin = new System.Windows.Forms.Padding(4);
            this.btnSearchTB.Name = "btnSearchTB";
            this.btnSearchTB.Size = new System.Drawing.Size(40, 37);
            this.btnSearchTB.TabIndex = 41;
            this.btnSearchTB.UseVisualStyleBackColor = false;
            this.btnSearchTB.Click += new System.EventHandler(this.btnSearchTB_Click);
            // 
            // picBoxTB
            // 
            this.picBoxTB.Location = new System.Drawing.Point(23, 18);
            this.picBoxTB.Margin = new System.Windows.Forms.Padding(4);
            this.picBoxTB.Name = "picBoxTB";
            this.picBoxTB.Size = new System.Drawing.Size(301, 183);
            this.picBoxTB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxTB.TabIndex = 50;
            this.picBoxTB.TabStop = false;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Transparent;
            this.tabPage4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage4.Controls.Add(this.pictureBox3);
            this.tabPage4.Controls.Add(this.pictureBox2);
            this.tabPage4.Controls.Add(this.pictureBox1);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.ImageIndex = 3;
            this.tabPage4.Location = new System.Drawing.Point(124, 4);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(956, 545);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Thông tin";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::QuanLy.Properties.Resources.Gym3;
            this.pictureBox3.Location = new System.Drawing.Point(356, 16);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(229, 128);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QuanLy.Properties.Resources.Gym2;
            this.pictureBox2.Location = new System.Drawing.Point(613, 16);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(272, 128);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::QuanLy.Properties.Resources.Gym;
            this.pictureBox1.Location = new System.Drawing.Point(23, 16);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(309, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Firebrick;
            this.groupBox1.Location = new System.Drawing.Point(103, 174);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(688, 338);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "BÀI TẬP LỚN";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(284, 268);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(133, 29);
            this.label10.TabIndex = 6;
            this.label10.Text = "2210000362";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(284, 214);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 29);
            this.label8.TabIndex = 4;
            this.label8.Text = "Lê Anh Huy";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(63, 214);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(213, 29);
            this.label7.TabIndex = 3;
            this.label7.Text = "Sinh viên thực hiện:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(63, 145);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(398, 29);
            this.label6.TabIndex = 2;
            this.label6.Text = "Bài tập lớn: QUẢN LÝ PHÒNG GYM";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(63, 76);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(220, 29);
            this.label5.TabIndex = 1;
            this.label5.Text = "Môn: Công nghệ.net";
            // 
            // imgList
            // 
            this.imgList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgList.ImageStream")));
            this.imgList.TransparentColor = System.Drawing.Color.Transparent;
            this.imgList.Images.SetKeyName(0, "user.png");
            this.imgList.Images.SetKeyName(1, "product.png");
            this.imgList.Images.SetKeyName(2, "sport.png");
            this.imgList.Images.SetKeyName(3, "infoicon.png");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(161, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(397, 42);
            this.label1.TabIndex = 2;
            this.label1.Text = "Gym OLYMPIA CLUP";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1081, 97);
            this.panel1.TabIndex = 5;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(911, 9);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(165, 62);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label33.Location = new System.Drawing.Point(164, 58);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(488, 24);
            this.label33.TabIndex = 3;
            this.label33.Text = "Hòa Hiệp Trung , Đông Hòa , Phú Yên (+84 363 475 837)";
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(13, 2);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(128, 92);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 646);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.tabCtrl);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý phòng gym";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabCtrl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvHoiVien)).EndInit();
            this.groupBoxHV.ResumeLayout(false);
            this.groupBoxHV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxHV)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvSanPham)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSP)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvThietBi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTB)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabCtrl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dtgvHoiVien;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnXoaHV;
        private System.Windows.Forms.Button btnSuaHV;
        private System.Windows.Forms.Button btnThemHV;
        private System.Windows.Forms.DataGridView dtgvSanPham;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtSearchHV;
        private System.Windows.Forms.Button btnSearchHV;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.TextBox txtMaHV;
        private System.Windows.Forms.ComboBox cmbGoiTap;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imgList;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.GroupBox groupBoxHV;
        private System.Windows.Forms.Button btnGiaHanHV;
        private System.Windows.Forms.PictureBox picBoxHV;
        private System.Windows.Forms.Label lblNgayHetHan;
        private System.Windows.Forms.Label lblHetHan;
        private System.Windows.Forms.ComboBox cmbGioiTinh;
        private System.Windows.Forms.Button btnLuuHV;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSuaSP;
        private System.Windows.Forms.Button btnXoaSP;
        private System.Windows.Forms.Button btnThemSP;
        private System.Windows.Forms.TextBox txtDonGiaSP;
        private System.Windows.Forms.PictureBox picBoxSP;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtSoLuongSP;
        private System.Windows.Forms.TextBox txtTenSP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLoaiSP;
        private System.Windows.Forms.Button btnSearchSP;
        private System.Windows.Forms.TextBox txtSearchSP;
        private System.Windows.Forms.Label lblTinhTrangSP;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_sp;
        private System.Windows.Forms.DataGridViewTextBoxColumn ten;
        private System.Windows.Forms.DataGridViewTextBoxColumn loai;
        private System.Windows.Forms.DataGridViewTextBoxColumn ngaynhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn soluong;
        private System.Windows.Forms.DataGridViewTextBoxColumn dongia;
        private System.Windows.Forms.DataGridViewTextBoxColumn trongluong;
        private System.Windows.Forms.DataGridViewTextBoxColumn hangsx;
        private System.Windows.Forms.DataGridViewTextBoxColumn tinhtrang;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLoaiTB;
        private System.Windows.Forms.Button btnSearchTB;
        private System.Windows.Forms.TextBox txtSearchTB;
        private System.Windows.Forms.Label lblTinhTrangTB;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnSuaTB;
        private System.Windows.Forms.Button btnThemTB;
        private System.Windows.Forms.Button btnXoaTB;
        private System.Windows.Forms.DataGridView dtgvThietBi;
        private System.Windows.Forms.TextBox txtHangSXTB;
        private System.Windows.Forms.PictureBox picBoxTB;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtSoLuongTB;
        private System.Windows.Forms.TextBox txtTenTB;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_hv;
        private System.Windows.Forms.DataGridViewTextBoxColumn hoten;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_tb;
        private System.Windows.Forms.DataGridViewTextBoxColumn tentb;
        private System.Windows.Forms.DataGridViewTextBoxColumn loaitb;
        private System.Windows.Forms.DataGridViewTextBoxColumn soluongtb;
        private System.Windows.Forms.DataGridViewTextBoxColumn hangsxtb;
        private System.Windows.Forms.DataGridViewTextBoxColumn tinhtrangtb;
        private System.Windows.Forms.DataGridViewTextBoxColumn soluonghu;
        private System.Windows.Forms.DataGridViewTextBoxColumn ghichu;
    }
}

