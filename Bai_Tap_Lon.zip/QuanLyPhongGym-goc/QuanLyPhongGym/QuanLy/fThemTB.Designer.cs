﻿namespace QuanLy
{
    partial class fThemTB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.picBoxTB = new System.Windows.Forms.PictureBox();
            this.txtGhiChuTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbTinhTrangTB = new System.Windows.Forms.ComboBox();
            this.txtHangSXTB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSoLuongHuTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnXoaHetSP = new System.Windows.Forms.Button();
            this.btnLuuSP = new System.Windows.Forms.Button();
            this.cmbLoaiTB = new System.Windows.Forms.ComboBox();
            this.txtSoLuongTB = new System.Windows.Forms.TextBox();
            this.txtTenTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTB)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.picBoxTB);
            this.groupBox1.Controls.Add(this.txtGhiChuTB);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cmbTinhTrangTB);
            this.groupBox1.Controls.Add(this.txtHangSXTB);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtSoLuongHuTB);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnXoaHetSP);
            this.groupBox1.Controls.Add(this.btnLuuSP);
            this.groupBox1.Controls.Add(this.cmbLoaiTB);
            this.groupBox1.Controls.Add(this.txtSoLuongTB);
            this.groupBox1.Controls.Add(this.txtTenTB);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(17, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(364, 494);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÊM THIẾT BỊ";
            // 
            // picBoxTB
            // 
            this.picBoxTB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBoxTB.Location = new System.Drawing.Point(76, 40);
            this.picBoxTB.Name = "picBoxTB";
            this.picBoxTB.Size = new System.Drawing.Size(205, 124);
            this.picBoxTB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxTB.TabIndex = 20;
            this.picBoxTB.TabStop = false;
            this.picBoxTB.Click += new System.EventHandler(this.picBoxHV_Click);
            // 
            // txtGhiChuTB
            // 
            this.txtGhiChuTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGhiChuTB.Location = new System.Drawing.Point(150, 389);
            this.txtGhiChuTB.Multiline = true;
            this.txtGhiChuTB.Name = "txtGhiChuTB";
            this.txtGhiChuTB.Size = new System.Drawing.Size(181, 51);
            this.txtGhiChuTB.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 391);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Ghi chú:";
            // 
            // cmbTinhTrangTB
            // 
            this.cmbTinhTrangTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTinhTrangTB.FormattingEnabled = true;
            this.cmbTinhTrangTB.Items.AddRange(new object[] {
            "Mới",
            "Tốt",
            "Hư"});
            this.cmbTinhTrangTB.Location = new System.Drawing.Point(150, 320);
            this.cmbTinhTrangTB.Name = "cmbTinhTrangTB";
            this.cmbTinhTrangTB.Size = new System.Drawing.Size(121, 24);
            this.cmbTinhTrangTB.TabIndex = 17;
            this.cmbTinhTrangTB.TextChanged += new System.EventHandler(this.cmbTinhTrangTB_TextChanged);
            // 
            // txtHangSXTB
            // 
            this.txtHangSXTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHangSXTB.Location = new System.Drawing.Point(150, 286);
            this.txtHangSXTB.Name = "txtHangSXTB";
            this.txtHangSXTB.Size = new System.Drawing.Size(181, 22);
            this.txtHangSXTB.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(31, 289);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "Hãng sản xuất:";
            // 
            // txtSoLuongHuTB
            // 
            this.txtSoLuongHuTB.Enabled = false;
            this.txtSoLuongHuTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoLuongHuTB.Location = new System.Drawing.Point(150, 354);
            this.txtSoLuongHuTB.Name = "txtSoLuongHuTB";
            this.txtSoLuongHuTB.Size = new System.Drawing.Size(181, 22);
            this.txtSoLuongHuTB.TabIndex = 6;
            this.txtSoLuongHuTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoLuongHuTB_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(31, 357);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 16);
            this.label6.TabIndex = 14;
            this.label6.Text = "Số lượng hư:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 323);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "Tình trạng:";
            // 
            // btnXoaHetSP
            // 
            this.btnXoaHetSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaHetSP.Location = new System.Drawing.Point(256, 456);
            this.btnXoaHetSP.Name = "btnXoaHetSP";
            this.btnXoaHetSP.Size = new System.Drawing.Size(75, 28);
            this.btnXoaHetSP.TabIndex = 9;
            this.btnXoaHetSP.Text = "Xóa hết";
            this.btnXoaHetSP.UseVisualStyleBackColor = true;
            this.btnXoaHetSP.Click += new System.EventHandler(this.btnXoaHetSP_Click_1);
            // 
            // btnLuuSP
            // 
            this.btnLuuSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuSP.Location = new System.Drawing.Point(168, 456);
            this.btnLuuSP.Name = "btnLuuSP";
            this.btnLuuSP.Size = new System.Drawing.Size(75, 28);
            this.btnLuuSP.TabIndex = 8;
            this.btnLuuSP.Text = "Lưu";
            this.btnLuuSP.UseVisualStyleBackColor = true;
            this.btnLuuSP.Click += new System.EventHandler(this.btnLuuSP_Click_1);
            // 
            // cmbLoaiTB
            // 
            this.cmbLoaiTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLoaiTB.FormattingEnabled = true;
            this.cmbLoaiTB.Items.AddRange(new object[] {
            "Máy",
            "Tạ"});
            this.cmbLoaiTB.Location = new System.Drawing.Point(150, 218);
            this.cmbLoaiTB.Name = "cmbLoaiTB";
            this.cmbLoaiTB.Size = new System.Drawing.Size(121, 24);
            this.cmbLoaiTB.TabIndex = 2;
            // 
            // txtSoLuongTB
            // 
            this.txtSoLuongTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoLuongTB.Location = new System.Drawing.Point(150, 252);
            this.txtSoLuongTB.Name = "txtSoLuongTB";
            this.txtSoLuongTB.Size = new System.Drawing.Size(181, 22);
            this.txtSoLuongTB.TabIndex = 4;
            this.txtSoLuongTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoLuongTB_KeyPress);
            // 
            // txtTenTB
            // 
            this.txtTenTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenTB.Location = new System.Drawing.Point(150, 184);
            this.txtTenTB.Name = "txtTenTB";
            this.txtTenTB.Size = new System.Drawing.Size(181, 22);
            this.txtTenTB.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(31, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Số lượng:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(31, 221);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Loại:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 187);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tên thiết bị:";
            // 
            // fThemTB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 520);
            this.Controls.Add(this.groupBox1);
            this.Name = "fThemTB";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm thiết bị";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTB)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtHangSXTB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSoLuongHuTB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnXoaHetSP;
        private System.Windows.Forms.Button btnLuuSP;
        private System.Windows.Forms.ComboBox cmbLoaiTB;
        private System.Windows.Forms.TextBox txtSoLuongTB;
        private System.Windows.Forms.TextBox txtTenTB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtGhiChuTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbTinhTrangTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox picBoxTB;
    }
}