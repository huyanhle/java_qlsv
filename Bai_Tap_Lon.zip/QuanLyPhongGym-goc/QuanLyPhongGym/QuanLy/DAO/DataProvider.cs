﻿using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;

namespace QuanLy.DAO
{
    public class DataProvider
    {
        string cnStr = "server=TONYHUYLE\\MAY1;database=PhongGym;Integrated Security=SSPI";
        protected SqlConnection connection;
        protected SqlDataAdapter adapter;
        protected SqlCommand cmd;

        public SqlConnection GetConnection()
        {
            if (connection == null)
            {
                connection = new SqlConnection(cnStr);
            }
            return connection;
        }

        public void connect()
        {
            if (connection == null)
            {
                connection = new SqlConnection(cnStr);
            }
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        public void disconnect()
        {
            if (connection != null && connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        public IDataReader executeQuery(string query)
        {
            connect();
            cmd = new SqlCommand(query, connection);
            return cmd.ExecuteReader();
        }

        public void executeNonQuery(string query, Byte[] img = null)
        {
            connect();
            cmd = new SqlCommand(query, connection);
            if (img != null)
                cmd.Parameters.AddWithValue("@img", img);
            cmd.ExecuteNonQuery();
            disconnect();
        }

        public object executeScalar(string query)
        {
            connect();
            cmd = new SqlCommand(query, connection);
            var result = cmd.ExecuteScalar();
            disconnect();
            return result;
        }

        public DataTable executeSelectCommand(string query)
        {
            connect();
            adapter = new SqlDataAdapter();
            cmd = new SqlCommand(query, connection);
            adapter.SelectCommand = cmd;

            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            disconnect();
            return dataTable;
        }

        protected ArrayList ConvertDataSetToArrayList(DataSet dataset)
        {
            ArrayList arr = new ArrayList();
            DataTable dt = dataset.Tables[0];
            int i, n = dt.Rows.Count;
            for (i = 0; i < n; i++)
            {
                object obj = GetDataFromDataRow(dt, i);
                arr.Add(obj);
            }
            return arr;
        }

        protected virtual object GetDataFromDataRow(DataTable dt, int i)
        {
            return null;
        }
    }
}
